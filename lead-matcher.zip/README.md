
# Lead Matcher (Kickstart → WLD)

Priority: phone (last 10 digits) then fallback to name ("Last, First" → "First Last", case-insensitive).

Outputs:
- `outputs/matched_rows.csv`
- `outputs/summary.json` and `outputs/summary.txt`
